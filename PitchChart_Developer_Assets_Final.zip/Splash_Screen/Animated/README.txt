
Animated Splash Concept
- Fade in shield logo (300ms)
- Hold 700ms
- Fade out to home screen
- No motion elements beyond opacity
