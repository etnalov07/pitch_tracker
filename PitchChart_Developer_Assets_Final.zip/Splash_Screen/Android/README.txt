
PitchChart Android Splash Screen
- Use PitchChart_Splash.png
- CenterInside
- Background color: #0B1F3A
