
PitchChart iOS Splash Screen
- Use PitchChart_Splash.png
- Center logo
- Use LaunchScreen.storyboard
- Background color: #0B1F3A
